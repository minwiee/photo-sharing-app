const express = require("express");
const User = require("../db/userModel");
const router = express.Router();

router.post("/", async (request, response) => {});

router.get("/list", async (request, response) => {
  try {
    const users = await User.find({}).select("_id first_name last_name");
    response.send(users);
  } catch (err) {
    response.status(400).send({ err });
  }
});
router.get("/:id", async (request, response) => {
  try {
    id = request.params.id;
    const user = await User.findOne({ _id: id });
    response.send(user);
  } catch (err) {
    response.status(400).send({ err });
  }
});

module.exports = router;
