const express = require("express");
const Photo = require("../db/photoModel");
const router = express.Router();

router.post("/", async (request, response) => {});

router.get("/photosOfUser/:id", async (request, response) => {
  try {
    const id = request.params.id;
    const photos = await Photo.find({ user_id: id });
    response.send(photos);
  } catch (error) {
    response.status(500).send({ error });
  }
});

module.exports = router;
